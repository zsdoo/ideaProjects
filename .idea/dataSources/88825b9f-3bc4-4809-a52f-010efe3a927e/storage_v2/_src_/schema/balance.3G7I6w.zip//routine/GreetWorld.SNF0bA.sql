create
    definer = root@`%` procedure GreetWorld()
SELECT CONCAT(@greeting,' World');

