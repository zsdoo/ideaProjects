create
    definer = root@`%` procedure p1()
    SET @last_procedure='p1';

