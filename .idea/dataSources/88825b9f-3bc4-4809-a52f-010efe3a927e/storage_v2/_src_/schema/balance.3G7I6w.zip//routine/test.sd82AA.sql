create
    definer = root@`%` procedure test()
BEGIN
DECLARE i int;

	SELECT * from tower_cdr_prepare ; 
	
END;

