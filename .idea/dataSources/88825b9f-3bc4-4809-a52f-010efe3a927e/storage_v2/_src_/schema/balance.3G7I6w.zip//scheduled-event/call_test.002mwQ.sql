create definer = root@`%` event call_test on schedule
    every '5' MINUTE
        starts '2021-09-29 07:49:43'
    disable
    do
    call test();

