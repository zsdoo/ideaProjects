create
    definer = root@`%` procedure p2()
SELECT CONCAT('Last procedure was ',@last_procedure);

